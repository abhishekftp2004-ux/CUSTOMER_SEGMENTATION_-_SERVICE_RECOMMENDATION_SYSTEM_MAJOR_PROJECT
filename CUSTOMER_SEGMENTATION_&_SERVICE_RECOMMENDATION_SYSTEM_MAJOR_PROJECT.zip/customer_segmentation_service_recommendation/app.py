from pathlib import Path
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs" / "segmented_customers.csv"
DATA = ROOT / "data" / "customer_data.csv"

st.set_page_config(page_title="Customer Segmentation & Service Recommendations", page_icon="📊", layout="wide")
st.title("Customer Segmentation & Service Recommendation System")
st.caption("Synthetic demonstration data — validate recommendations before operational use.")

if OUTPUT.exists():
    df = pd.read_csv(OUTPUT)
else:
    st.warning("Processed outputs not found. Run `python run_pipeline.py` first.")
    df = pd.read_csv(DATA)

if "customer_segment" not in df.columns:
    st.info("Showing raw sample data until the pipeline is run.")
    st.dataframe(df.head(20), use_container_width=True)
    st.stop()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Customers", f"{len(df):,}")
c2.metric("Segments", df["cluster_id"].nunique())
c3.metric("Average monthly spend", f"₹{df['monthly_spend_inr'].mean():,.0f}")
c4.metric("Average engagement", f"{df['engagement_score'].mean():.1f}/100")

st.subheader("Customer segment overview")
segment_counts = df["customer_segment"].value_counts().rename_axis("segment").reset_index(name="customers")
st.bar_chart(segment_counts.set_index("segment"))

left, right = st.columns(2)
with left:
    st.subheader("Cluster profiles")
    profile_path = ROOT / "outputs" / "cluster_profiles.csv"
    if profile_path.exists():
        st.dataframe(pd.read_csv(profile_path), use_container_width=True)
with right:
    st.subheader("2D cluster visualization")
    chart_path = ROOT / "outputs" / "customer_clusters.png"
    if chart_path.exists():
        st.image(str(chart_path), use_container_width=True)
    else:
        st.info("Run the pipeline to create the cluster visualization.")

st.subheader("Find customers and recommendations")
segments = ["All"] + sorted(df["customer_segment"].dropna().unique().tolist())
selected = st.selectbox("Filter by segment", segments)
search = st.text_input("Search customer ID")
view = df.copy()
if selected != "All":
    view = view[view["customer_segment"] == selected]
if search.strip():
    view = view[view["customer_id"].astype(str).str.contains(search.strip(), case=False, na=False)]
columns = ["customer_id", "customer_segment", "cluster_id", "engagement_score", "website_visits_30d", "monthly_spend_inr", "service_inquiries_90d", "service_recommendation"]
st.dataframe(view[columns], use_container_width=True, hide_index=True)

csv = view.to_csv(index=False).encode("utf-8")
st.download_button("Download filtered customer results (CSV)", csv, "customer_recommendations.csv", "text/csv")
