from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "customer_data.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

NUMERIC_FEATURES = [
    "age", "website_visits_30d", "monthly_spend_inr",
    "service_inquiries_90d", "engagement_score", "tenure_months",
    "satisfaction_score", "courses_enrolled"
]
CATEGORICAL_FEATURES = ["preferred_channel", "region"]

def segment_name(row, medians):
    if row["engagement_score"] >= medians["engagement_score"] and row["website_visits_30d"] >= medians["website_visits_30d"]:
        return "Highly Engaged Customers"
    if row["service_inquiries_90d"] >= medians["service_inquiries_90d"] and row["service_inquiries_90d"] >= 5:
        return "Service-Focused Customers"
    if row["tenure_months"] <= 5:
        return "New Customers"
    return "Occasional Users"

def recommend(row):
    recs = []
    if row["engagement_score"] >= 75 and row["website_visits_30d"] >= 12:
        recs.append("Advanced learning program or premium service bundle")
    elif row["tenure_months"] <= 5:
        recs.append("New-customer onboarding and introductory learning path")
    elif row["service_inquiries_90d"] >= 5:
        recs.append("Guided consultation, support clinic, or service walkthrough")
    elif row["website_visits_30d"] <= 5:
        recs.append("Re-engagement campaign with a short, relevant learning module")
    else:
        recs.append("Personalized course recommendation and monthly service package")
    if row["courses_enrolled"] == 0:
        recs.append("Beginner-friendly starter course")
    if row["satisfaction_score"] <= 3:
        recs.append("Follow-up satisfaction check and proactive support")
    return " | ".join(recs)

def main():
    df = pd.read_csv(DATA_PATH)
    df["monthly_spend_inr"] = pd.to_numeric(df["monthly_spend_inr"], errors="coerce")
    num_imputer = SimpleImputer(strategy="median")
    X_num = pd.DataFrame(num_imputer.fit_transform(df[NUMERIC_FEATURES]), columns=NUMERIC_FEATURES, index=df.index)
    cat_imputer = SimpleImputer(strategy="most_frequent")
    X_cat = pd.DataFrame(cat_imputer.fit_transform(df[CATEGORICAL_FEATURES]), columns=CATEGORICAL_FEATURES, index=df.index)
    medians = X_num.median()
    X_scaled = StandardScaler().fit_transform(X_num)

    # Compare candidate cluster counts with inertia and silhouette score.
    metrics = []
    for k in range(2, 9):
        model = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = model.fit_predict(X_scaled)
        metrics.append({"k": k, "inertia": float(model.inertia_), "silhouette": float(silhouette_score(X_scaled, labels))})
    pd.DataFrame(metrics).to_csv(OUT / "cluster_metrics.csv", index=False)

    # Four clusters are used as a practical starting point; tune after reviewing metrics.
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
    labels = kmeans.fit_predict(X_scaled)
    pca = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(X_scaled)

    result = df.copy()
    for col in NUMERIC_FEATURES:
        result[col] = X_num[col]
    for col in CATEGORICAL_FEATURES:
        result[col] = X_cat[col]
    result["cluster_id"] = labels
    result["pca_1"] = coords[:, 0]
    result["pca_2"] = coords[:, 1]
    result["customer_segment"] = result.apply(lambda r: segment_name(r, medians), axis=1)
    result["service_recommendation"] = result.apply(recommend, axis=1)
    result.to_csv(OUT / "segmented_customers.csv", index=False)

    profile = result.groupby("cluster_id").agg(
        customer_count=("customer_id", "count"),
        avg_age=("age", "mean"),
        avg_visits=("website_visits_30d", "mean"),
        avg_monthly_spend_inr=("monthly_spend_inr", "mean"),
        avg_service_inquiries=("service_inquiries_90d", "mean"),
        avg_engagement=("engagement_score", "mean"),
        avg_tenure_months=("tenure_months", "mean"),
        avg_satisfaction=("satisfaction_score", "mean"),
        avg_courses=("courses_enrolled", "mean")
    ).round(2).reset_index()
    profile.to_csv(OUT / "cluster_profiles.csv", index=False)

    sns.set_theme()
    plt.figure(figsize=(8, 5))
    m = pd.DataFrame(metrics)
    plt.plot(m["k"], m["inertia"], marker="o")
    plt.xlabel("Number of clusters (k)")
    plt.ylabel("Inertia")
    plt.title("Elbow Method")
    plt.tight_layout()
    plt.savefig(OUT / "elbow_method.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(m["k"], m["silhouette"], marker="o")
    plt.xlabel("Number of clusters (k)")
    plt.ylabel("Silhouette score")
    plt.title("Silhouette Score by Cluster Count")
    plt.tight_layout()
    plt.savefig(OUT / "silhouette_scores.png", dpi=160)
    plt.close()

    plt.figure(figsize=(9, 6))
    sns.scatterplot(data=result, x="pca_1", y="pca_2", hue="cluster_id", palette="tab10", s=35)
    plt.title("Customer Segments (PCA 2D Projection)")
    plt.tight_layout()
    plt.savefig(OUT / "customer_clusters.png", dpi=160)
    plt.close()

    summary = {
        "rows": int(len(result)),
        "features_used": NUMERIC_FEATURES,
        "selected_k": 4,
        "best_silhouette_k": int(m.loc[m["silhouette"].idxmax(), "k"]),
        "best_silhouette_score": round(float(m["silhouette"].max()), 4),
        "note": "Synthetic demonstration data; replace with approved real customer data before business use."
    }
    (OUT / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    joblib.dump({"kmeans": kmeans, "scaler": StandardScaler().fit(X_num), "numeric_features": NUMERIC_FEATURES}, OUT / "clustering_model.joblib")
    print("Pipeline complete. See the outputs/ folder.")

if __name__ == "__main__":
    main()
