# Final Major Project Submission Checklist

## Included
- Python pipeline: `run_pipeline.py`
- Streamlit dashboard: `app.py`
- Synthetic input dataset: `data/customer_data.csv`
- Jupyter notebook: `Customer_Segmentation_Analysis.ipynb`
- Elbow, silhouette, and PCA cluster graphs
- Evaluation metrics and cluster profile tables
- Segmented customer output with service recommendations
- Saved model artifact
- Requirements and README
- Expanded PDF documentation with graphs and code appendices
- Major-project presentation (`Customer_Segmentation_Major_Project_Presentation.pptx`)

## Run on Windows
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run_pipeline.py
streamlit run app.py
```

## Before submission
1. Add your name, roll number, department, college, project guide, and academic year to the presentation/report where required.
2. Run the pipeline and dashboard on your own computer and capture screenshots.
3. Confirm figures and metrics match the latest pipeline run.
4. Cite any external material added and follow college formatting rules.
5. Clearly disclose that the included dataset is synthetic.
6. Review cluster selection: the demo uses k=4 for detailed profiles, while k=2 scored best on silhouette in the saved run.
